import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panel-why',
  templateUrl: './panel-why.component.html',
  styleUrls: ['./panel-why.component.scss']
})
export class PanelWhyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
